package ict.bean;

public class OrderRecordBean {

    private String orderId;
    private String furnId;

    public OrderRecordBean() {
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getFurnId() {
        return furnId;
    }

    public void setFurnId(String furnId) {
        this.furnId = furnId;
    }
    
}
